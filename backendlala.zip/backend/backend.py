from flask import Flask, request, jsonify
from predictor import predict_price

app = Flask(__name__)

@app.route('/predict', methods=['POST'])
def predict():
    data = request.json
    ans = predict_price(data)
    return jsonify({'price': ans})

if __name__ == '__main__':
   app.run()